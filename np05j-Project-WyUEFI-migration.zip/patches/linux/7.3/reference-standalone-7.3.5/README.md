# Reference Standalone Linux 7.3.5 Patches (DO NOT copy verbatim into Project-WyUEFI/patches/)

These are the original standalone patches from `np05j-linux-7.3.5-kernel.zip`.
In Project-WyUEFI (which already carries `0001-platform.patch` .. `0140-LOCAL-*.patch`),
only the rebased `0141`, `0142`, and `0143` patches in the parent directory are needed:

- `0001` (BRAHMA 2.0 Peri baudrate): DROPPED — already covered by `0003-input-wireless.patch` (`qca_peach_fast_uart` + PERI 0x31/0x34).
- `0002` (Synaptics TCM2 SPI): REBASED as `../0141-LOCAL-input-touchscreen-synaptics-tcm2-spi.patch`.
- `0003` (`ath12k` WCN7861 `0x110e` + `bdwlan.e%02x`): PCI ID/HAL DROPPED (covered by `0003-input-wireless.patch` `PEACH_DEVICE_ID 0x110e`); `bdwlan.e%02x` fallback REBASED as `../0143-LOCAL-wifi-ath12k-bdwlan-board-id-fallback.patch`.
- `0004` (`pci17cb,110e` pwrctrl): DROPPED — already in `0001-platform.patch`.
- `0005` (Adreno 830v2 `0x44050001`): DROPPED — already in `0002-display.patch`.
- `0006` (NP05J DTS/DTSI + Makefile): REBASED as `../0142-LOCAL-arm64-dts-qcom-sm8750-nubia-np05j.patch`.
- `0007` (`qcom_pcie_config_sid_1_9_0` dynamic `#iommu-cells`): DROPPED — already in `0001-platform.patch`.
