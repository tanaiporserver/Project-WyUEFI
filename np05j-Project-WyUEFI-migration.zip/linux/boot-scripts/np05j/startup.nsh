@echo -off
for %d in fs0 fs1 fs2 fs3 fs4 fs5 fs6 fs7 fs8 fs9
  if exist %d:\NP05J\LINUX\VMLINUZ.EFI then
    %d:
    cd \NP05J\LINUX
    echo "=============================================================="
    echo " nubia NP05J (REDMAGIC Astra) - Mainline Linux 7.3.5 Phase 3"
    echo "=============================================================="
    echo "  BOOTDT.NSH      : SM8750 DT (Touch+WiFi7+BT+NPU+Batt+ttyGS0)"
    echo "  BOOTDT_GPU.NSH  : SM8750 DT + Adreno 830v2 GPU (headless DRM)"
    echo "  BOOTDT_OTG.NSH  : SM8750 DT + USB-C Dual-Role Host/OTG + USB3"
    echo "  BOOTDT_SAFE.NSH : SM8750 DT without PCIe0/Remoteproc (fallback)"
    echo "  BOOTACPI.NSH    : Linux 7.3.5 ACPI mode (EFI Runtime ON)"
    echo "=============================================================="
    goto done
  endif
endfor
:done
