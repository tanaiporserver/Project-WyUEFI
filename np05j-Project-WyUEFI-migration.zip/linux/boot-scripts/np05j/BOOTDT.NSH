@echo -off
echo "=============================================================="
echo " Booting Mainline Linux 7.3.5 SM8750 DT (Phase 3)"
echo " Touch S3930 + Wi-Fi 7 WCN7861 + BT + ADSP/CDSP + Fan + ttyGS0"
echo "=============================================================="
\NP05J\LINUX\VMLINUZ.EFI dtb=\NP05J\LINUX\NP05J.DTB initrd=\NP05J\LINUX\INITRD.XZ acpi=off efi=debug earlycon=efifb clk_ignore_unused pd_ignore_unused fbcon=font:TER16x32 console=tty0 loglevel=7 ignore_loglevel
