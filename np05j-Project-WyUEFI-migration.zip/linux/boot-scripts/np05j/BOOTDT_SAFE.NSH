@echo -off
echo "Booting Linux 7.3.5 SM8750 DT (Safe fallback: no PCIe0/Remoteproc)..."
\NP05J\LINUX\VMLINUZ.EFI dtb=\NP05J\LINUX\NP05J.DTB initrd=\NP05J\LINUX\INITRD.XZ acpi=off efi=debug earlycon=efifb clk_ignore_unused pd_ignore_unused initcall_blacklist=qcom_pcie_driver_init,qcom_pas_driver_init fbcon=font:TER16x32 console=tty0 loglevel=7 ignore_loglevel
