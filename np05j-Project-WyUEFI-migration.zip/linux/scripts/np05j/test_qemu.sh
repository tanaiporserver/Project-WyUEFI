#!/bin/bash
set -euo pipefail

IMG=/workspaces/Mu-Silicium/Device_np05j/logfs-linux7-dt.img
CODE=/usr/share/AAVMF/AAVMF_CODE.fd
VARS=/tmp/np05j-linux7/qemu_vars.fd

cp /usr/share/AAVMF/AAVMF_VARS.fd "$VARS"

echo "=== QEMU TEST 1: Full Linux 7.3.5 ACPI boot from 4K-sector logfs-linux7-dt.img ==="
python3 - <<'PY'
import subprocess, time, os, select, sys

cmd = [
    "qemu-system-aarch64",
    "-machine", "virt,gic-version=3",
    "-cpu", "cortex-a72",
    "-smp", "4",
    "-m", "2048",
    "-display", "none",
    "-net", "none",
    "-device", "ramfb",
    "-serial", "stdio",
    "-drive", "if=pflash,format=raw,readonly=on,file=/usr/share/AAVMF/AAVMF_CODE.fd",
    "-drive", "if=pflash,format=raw,file=/tmp/np05j-linux7/qemu_vars.fd",
    "-drive", "id=logfs,file=/workspaces/Mu-Silicium/Device_np05j/logfs-linux7-dt.img,format=raw,if=none",
    "-device", "virtio-blk-pci,drive=logfs,logical_block_size=4096,physical_block_size=4096,romfile=",
]

p = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
buf = b""
sent_boot = False
sent_cmd = False
t0 = time.time()

while time.time() - t0 < 45:
    r, _, _ = select.select([p.stdout], [], [], 0.5)
    if r:
        chunk = os.read(p.stdout.fileno(), 4096)
        if not chunk:
            break
        buf += chunk
        text = buf.decode("utf-8", "replace")
        if not sent_boot and "BOOTACPI.NSH" in text and "FS0:\\NP05J\\LINUX\\>" in text:
            p.stdin.write(b"\\NP05J\\LINUX\\VMLINUZ.EFI initrd=\\NP05J\\LINUX\\INITRD.XZ acpi=force earlycon=pl011,0x09000000 console=tty0 console=ttyAMA0 loglevel=7\r\n")
            p.stdin.flush()
            sent_boot = True
        if sent_boot and not sent_cmd and "NP05J Mainline Linux 7.3.5 Phase3 ready!" in text:
            p.stdin.write(b"uname -a; ls /sys/class/graphics/fb0; np05j-tool 2>&1 || true; echo QEMU_TEST1_PASS\n")
            p.stdin.flush()
            sent_cmd = True
        if "QEMU_TEST1_PASS" in text:
            time.sleep(0.3)
            break

p.terminate()
try:
    p.wait(timeout=3)
except Exception:
    p.kill()

out = buf.decode("utf-8", "replace")
with open("/tmp/np05j-linux7/qemu_test1.log", "w") as f:
    f.write(out)

# Print relevant section
for line in out.splitlines():
    if any(k in line for k in ["EFI stub", "Linux version", "nubia NP05J", "Kernel :", "ACPI   :", "CPUs   :", "Memory :", "FB0    :", "SMMU   :", "Storage", "/dev/vd", "UDC", "NP05J Mainline", "QEMU_TEST1_PASS", "Panic", "panic", "Unable"]):
        print(line)

assert "QEMU_TEST1_PASS" in out, "QEMU Test 1 did not reach shell!"
print("QEMU TEST 1 PASSED!")
PY

echo ""
echo "=== QEMU TEST 2: Verify EFI stub loads dtb=\NP05J\LINUX\NP05J.DTB cleanly ==="
cp /usr/share/AAVMF/AAVMF_VARS.fd "$VARS"
python3 - <<'PY'
import subprocess, time, os, select

cmd = [
    "qemu-system-aarch64",
    "-machine", "virt,gic-version=3",
    "-cpu", "cortex-a72",
    "-smp", "2",
    "-m", "1024",
    "-display", "none",
    "-net", "none",
    "-serial", "stdio",
    "-drive", "if=pflash,format=raw,readonly=on,file=/usr/share/AAVMF/AAVMF_CODE.fd",
    "-drive", "if=pflash,format=raw,file=/tmp/np05j-linux7/qemu_vars.fd",
    "-drive", "id=logfs,file=/workspaces/Mu-Silicium/Device_np05j/logfs-linux7-dt.img,format=raw,if=none",
    "-device", "virtio-blk-pci,drive=logfs,logical_block_size=4096,physical_block_size=4096,romfile=",
]

p = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
buf = b""
sent = False
t0 = time.time()

while time.time() - t0 < 25:
    r, _, _ = select.select([p.stdout], [], [], 0.5)
    if r:
        chunk = os.read(p.stdout.fileno(), 4096)
        if not chunk:
            break
        buf += chunk
        text = buf.decode("utf-8", "replace")
        if not sent and "FS0:\\NP05J\\LINUX\\>" in text:
            p.stdin.write(b"BOOTDT.NSH\r\n")
            p.stdin.flush()
            sent = True
        if "Exiting boot services..." in text:
            time.sleep(0.5)
            break

p.terminate()
try:
    p.wait(timeout=3)
except Exception:
    p.kill()

out = buf.decode("utf-8", "replace")
with open("/tmp/np05j-linux7/qemu_test2.log", "w") as f:
    f.write(out)

for line in out.splitlines():
    if "EFI stub" in line or "Booting Mainline" in line or "DTB" in line or "Failed" in line or "Ignoring" in line:
        print(line)

assert "Using DTB from command line" in out, "EFI stub did NOT load NP05J.DTB!"
assert "Loaded initrd from command line option" in out, "EFI stub did NOT load INITRD.XZ!"
assert "Exiting boot services..." in out, "EFI stub did NOT reach ExitBootServices!"
print("QEMU TEST 2 PASSED (EFI stub parsed & loaded NP05J.DTB + INITRD.XZ cleanly)!")
PY

echo ""
echo "=== QEMU TEST 3: Verify EFI stub loads BOOTDT_OTG.NSH (NP05JOTG.DTB) cleanly ==="
cp /usr/share/AAVMF/AAVMF_VARS.fd "$VARS"
python3 - <<'PY'
import subprocess, time, os, select

cmd = [
    "qemu-system-aarch64",
    "-machine", "virt,gic-version=3",
    "-cpu", "cortex-a72",
    "-smp", "2",
    "-m", "1024",
    "-display", "none",
    "-net", "none",
    "-serial", "stdio",
    "-drive", "if=pflash,format=raw,readonly=on,file=/usr/share/AAVMF/AAVMF_CODE.fd",
    "-drive", "if=pflash,format=raw,file=/tmp/np05j-linux7/qemu_vars.fd",
    "-drive", "id=logfs,file=/workspaces/Mu-Silicium/Device_np05j/logfs-linux7-dt.img,format=raw,if=none",
    "-device", "virtio-blk-pci,drive=logfs,logical_block_size=4096,physical_block_size=4096,romfile=",
]

p = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
buf = b""
sent = False
t0 = time.time()

while time.time() - t0 < 25:
    r, _, _ = select.select([p.stdout], [], [], 0.5)
    if r:
        chunk = os.read(p.stdout.fileno(), 4096)
        if not chunk:
            break
        buf += chunk
        text = buf.decode("utf-8", "replace")
        if not sent and "FS0:\\NP05J\\LINUX\\>" in text:
            p.stdin.write(b"BOOTDT_OTG.NSH\r\n")
            p.stdin.flush()
            sent = True
        if "Exiting boot services..." in text:
            time.sleep(0.5)
            break

p.terminate()
try:
    p.wait(timeout=3)
except Exception:
    p.kill()

out = buf.decode("utf-8", "replace")
for line in out.splitlines():
    if "EFI stub" in line or "USB-C Host/OTG" in line or "Failed" in line:
        print(line)

assert "Using DTB from command line" in out, "EFI stub did NOT load NP05JOTG.DTB!"
assert "Exiting boot services..." in out, "EFI stub did NOT reach ExitBootServices!"
print("QEMU TEST 3 PASSED (EFI stub parsed & loaded NP05JOTG.DTB cleanly)!")
PY

echo ""
echo "=== QEMU TEST 4: Verify EFI stub loads BOOTDT_GPU.NSH (NP05JGPU.DTB) cleanly ==="
cp /usr/share/AAVMF/AAVMF_VARS.fd "$VARS"
python3 - <<'PY'
import subprocess, time, os, select

cmd = [
    "qemu-system-aarch64",
    "-machine", "virt,gic-version=3",
    "-cpu", "cortex-a72",
    "-smp", "2",
    "-m", "1024",
    "-display", "none",
    "-net", "none",
    "-serial", "stdio",
    "-drive", "if=pflash,format=raw,readonly=on,file=/usr/share/AAVMF/AAVMF_CODE.fd",
    "-drive", "if=pflash,format=raw,file=/tmp/np05j-linux7/qemu_vars.fd",
    "-drive", "id=logfs,file=/workspaces/Mu-Silicium/Device_np05j/logfs-linux7-dt.img,format=raw,if=none",
    "-device", "virtio-blk-pci,drive=logfs,logical_block_size=4096,physical_block_size=4096,romfile=",
]

p = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
buf = b""
sent = False
t0 = time.time()

while time.time() - t0 < 25:
    r, _, _ = select.select([p.stdout], [], [], 0.5)
    if r:
        chunk = os.read(p.stdout.fileno(), 4096)
        if not chunk:
            break
        buf += chunk
        text = buf.decode("utf-8", "replace")
        if not sent and "FS0:\\NP05J\\LINUX\\>" in text:
            p.stdin.write(b"BOOTDT_GPU.NSH\r\n")
            p.stdin.flush()
            sent = True
        if "Exiting boot services..." in text:
            time.sleep(0.5)
            break

p.terminate()
try:
    p.wait(timeout=3)
except Exception:
    p.kill()

out = buf.decode("utf-8", "replace")
for line in out.splitlines():
    if "EFI stub" in line or "Adreno 830v2" in line or "Failed" in line:
        print(line)

assert "Using DTB from command line" in out, "EFI stub did NOT load NP05JGPU.DTB!"
assert "Exiting boot services..." in out, "EFI stub did NOT reach ExitBootServices!"
print("QEMU TEST 4 PASSED (EFI stub parsed & loaded NP05JGPU.DTB cleanly)!")
PY
